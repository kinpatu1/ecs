import boto3
import json
import os
import base64
from botocore.exceptions import ClientError

ecs = boto3.client('ecs')
CRUSTER_NAME = os.environ['CRUSTER_NAME']
CRUD_FOR_ECS_SECRET_NAME = os.environ['CRUD_FOR_ECS_SECRET_NAME']
TASK_DEFINITION = os.environ['TASK_DEFINITION']
SUBNET_1 = os.environ['SUBNET_1']
SUBNET_2 = os.environ['SUBNET_2']
SG_NAME = os.environ['SG_NAME']
CONTAINER_NAME = os.environ['CONTAINER_NAME']

def lambda_handler(event, context):
    session = boto3.session.Session()
    region_name='ap-northeast-1'

    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=CRUD_FOR_ECS_SECRET_NAME
        )
        
    except ClientError as e:
            raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret_data = get_secret_value_response['SecretString']
        else:
            secret_data = base64.b64decode(get_secret_value_response['SecretBinary'])

    secret_data_dict = json.loads(secret_data)
    cluster_name = secret_data_dict[CRUSTER_NAME]
    task_definition = secret_data_dict[TASK_DEFINITION]
    subnet_1 = secret_data_dict[SUBNET_1]
    subnet_2 = secret_data_dict[SUBNET_2]
    sg_name = secret_data_dict[SG_NAME]
    container_name = secret_data_dict[CONTAINER_NAME]

    # ECSタスクの実行（単発）
    response = ecs.run_task(
        cluster=cluster_name,
        taskDefinition=task_definition,
        launchType='FARGATE',
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': [
                    subnet_1,
                    subnet_2
                ],
                'securityGroups': [
                    sg_name
                ],
                'assignPublicIp': 'ENABLED'
            }
        },
        overrides={
            'containerOverrides': [
                {
                    'name': container_name,
                    'command': ["python3", "src/main.py"]
                }
            ]
        }
    )

    # エラーの検知
    failures = response['failures']
    if len(failures) != 0:
        print(failures)
        return {
            'statusCode': 500,
            'body': json.dumps('NG!')
        }

    # 正常終了
    return {
        'statusCode': 200,
        'body': json.dumps('OK!')
    }
